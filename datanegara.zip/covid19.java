import java.util.*;
import java.io.*;
public class covid19{
	public static Scanner in = new Scanner(System.in);
	public static void main (String[] args) {
		System.out.println("\t\tPERHATIAN");
		System.out.println("DISINI KAMI HANYA MENGAMBIL 11 SAMPEL NEGARA\n");
		mainmenu();
	}
	public static void mainmenu(){
		System.out.println("===============================");
		System.out.println("Data Negara Terinfeksi COVID-19");
		System.out.println("===============================");
		int choose;
		do{
		System.out.println("");
		System.out.println("Menu");
		System.out.println("1. Daftar Negara\n2. Semua Negara\n3. Exit");
		System.out.print("Pilihan: ");
		choose = in.nextInt();
		System.out.println();
		switch(choose)
		{
			case 1 : daftar(); break;
			case 2 : negara(); break;
			case 3 : System.out.println("Terima Kasih");break;
			default : System.out.println("ERROR. Pilihan tidak ada."); System.out.println(""); mainmenu();
		}}
		while(choose != 3);
	}
	public static void daftar(){
		try {
			FileReader reader = new FileReader("daftar.txt");
			int character;
			while ((character = reader.read()) != -1){
				System.out.print((char) character);
			}
			reader.close();
		}
		catch (IOException e) {
            e.printStackTrace();
        }
		System.out.println();
	}
	
	public static void negara(){
		try {
			FileReader reader = new FileReader("Negara.txt");
			int character;
			while ((character = reader.read()) != -1){
				System.out.print((char) character);
			}
			reader.close();
		}
		catch (IOException e) {
            e.printStackTrace();
        }
		System.out.println();
	}
}